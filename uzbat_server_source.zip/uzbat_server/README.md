# UZBAT server — boshlang‘ich versiya

## Nimalar bor?
- Foydalanuvchi ro‘yxatdan o‘tishi va kirishi
- Admin login/parol orqali kirishi
- Uzcard/Humo o‘tkazmasi uchun chek yuklash va admin qo‘lda ko‘rib chiqishi
- Vazifalar arizasi va admin tasdig‘i
- Balans hisob-kitobi va pul yechish arizasi
- SQLite ma’lumotlar bazasi; chek fayllari serverda saqlanadi

## Mahalliy ishga tushirish
1. Node.js 20 yoki yangiroq o‘rnating.
2. Ushbu papkada terminal oching.
3. `.env.example` faylini `.env` nomi bilan nusxalang.
4. `.env` ichida `SESSION_SECRET` uchun uzun tasodifiy qiymat va `ADMIN_PASSWORD` uchun kuchli parol yozing.
5. `npm install`
6. `npm start`
7. Brauzerda `http://localhost:3000` ni oching.

## Internetga joylash
Node.js qo‘llaydigan hostingga loyihani yuklang, `npm install` va `npm start` sozlang, quyidagi environment variables kiriting:
- `NODE_ENV=production`
- `SESSION_SECRET` — kamida 32 belgili tasodifiy sir
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`
- `PORT` — hosting bergan qiymat bo‘lsa

**Muhim:** hosting doimiy diskni qo‘llashi kerak, chunki SQLite bazasi `data/` va chek fayllari `uploads/` ichida saqlanadi. Doimiy disk bo‘lmasa ma’lumotlar yo‘qolishi mumkin. Production uchun HTTPS, avtomatik backup, rate limiting, CSRF himoyasi, fayllar uchun virus tekshiruvi, maxfiy ma’lumotlar siyosati va xavfsizlik auditi qo‘shilishi kerak.

## To‘lovlar
Bu versiya avtomatik karta integratsiyasi emas. Foydalanuvchi Uzcard/Humo orqali alohida to‘lov qiladi va chek yuklaydi. Admin bank ilovasida pul haqiqatan tushganini tekshiradi, so‘ng arizani tasdiqlaydi. Foydalanuvchining karta PIN/CVV/SMS kodlarini yig‘mang. Sayt o‘zi bank pul o‘tkazmasini amalga oshirmaydi.

## Sarmoya paketlari
Ushbu starter loyiha sarmoya qabul qilmaydi va kunlik foydani kafolatlamaydi. “30 000 so‘m kiriting va har kuni 3 000 so‘m” kabi takliflarni haqiqiy daromad manbasi, qonuniy talablar va to‘lov qobiliyati mustaqil tekshirilmaguncha ishga tushirmang. Vazifa mukofotlari uchun mablag‘ haqiqatan mavjud bo‘lishi va qoidalar ochiq ko‘rsatilishi kerak.
