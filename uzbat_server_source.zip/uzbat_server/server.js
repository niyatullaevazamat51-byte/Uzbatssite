require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === "production";
const dataDir = path.join(__dirname, "data");
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

if (isProd && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32)) {
  throw new Error("Set SESSION_SECRET to a random string of at least 32 characters.");
}
const db = new Database(path.join(dataDir, "uzbat.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 kind TEXT NOT NULL CHECK(kind IN ('deposit','withdraw','task')),
 amount INTEGER NOT NULL CHECK(amount > 0), note TEXT DEFAULT '',
 proof_file TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'pending'
 CHECK(status IN ('pending','approved','rejected')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS ledger (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
 amount INTEGER NOT NULL, description TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
 description TEXT NOT NULL, reward INTEGER NOT NULL CHECK(reward >= 0), active INTEGER NOT NULL DEFAULT 1
);
`);
const taskCount = db.prepare("SELECT COUNT(*) n FROM tasks").get().n;
if (!taskCount) {
  const ins = db.prepare("INSERT INTO tasks(title,description,reward) VALUES(?,?,?)");
  ins.run("Kanal yoki sahifani kuzatish", "Hamkor topshirig‘ini bajaring va natijani izohda yuboring.", 1000);
  ins.run("Video ko‘rib fikr bildirish", "Videoni ko‘rib, mazmunli fikr yozing.", 1500);
  ins.run("Matnni tekshirish", "Qisqa matndagi imlo xatolarini toping.", 2000);
}
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadDir),
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${Math.random().toString(36).slice(2)}${path.extname(file.originalname).toLowerCase()}`)
  }),
  limits: { fileSize: 4 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ok = ["image/jpeg", "image/png", "image/webp", "application/pdf"].includes(file.mimetype);
    cb(ok ? null : new Error("Faqat JPG, PNG, WEBP yoki PDF chek qabul qilinadi."), ok);
  }
});

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret-before-deploying",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: isProd, maxAge: 1000 * 60 * 60 * 8 }
}));
app.use("/static", express.static(path.join(__dirname, "public")));
app.use("/receipts", (req, res, next) => {
  if (!req.session.userId || !req.session.isAdmin) return res.status(403).send("Ruxsat yo‘q");
  next();
}, express.static(uploadDir));

function esc(s="") {
  return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function money(n) { return Number(n).toLocaleString("uz-UZ") + " so‘m"; }
function page(title, body, req) {
  const user = req.session.userId ? `<span class="muted">Kirish: ${esc(req.session.username)}</span> <form method="post" action="/logout" class="inline"><button class="secondary">Chiqish</button></form>` : `<a class="button" href="/login">Kirish</a>`;
  return `<!doctype html><html lang="uz"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} — UZBAT</title><link rel="stylesheet" href="/static/style.css"></head><body><header><a class="logo" href="/">UZ<span>BAT</span></a><nav>${user}</nav></header><main>${body}</main><footer>UZBAT • boshlang‘ich versiya • To‘lovlarni admin qo‘lda tekshiradi</footer></body></html>`;
}
function flash(req) { const m = req.session.flash; delete req.session.flash; return m ? `<div class="notice">${esc(m)}</div>` : ""; }
function requireUser(req, res, next) {
  if (!req.session.userId) return res.redirect("/login");
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.userId || !req.session.isAdmin) return res.status(403).send(page("Ruxsat yo‘q", "<section class='box'><h1>Ruxsat yo‘q</h1><p>Admin hisobiga kiring.</p><a class='button' href='/login'>Kirish</a></section>", req));
  next();
}
function balance(userId) {
  return db.prepare("SELECT COALESCE(SUM(amount),0) n FROM ledger WHERE user_id=?").get(userId).n;
}
function requestForm(kind, title, req) {
  const isDeposit = kind === "deposit";
  return page(title, `${flash(req)}<section class="box"><h1>${title}</h1><p>${isDeposit ? "To‘lovni Uzcard yoki Humo ilovangiz orqali amalga oshiring, so‘ng chekni yuklang. Admin chekni tekshirib tasdiqlaydi." : "Faqat balansingizdagi mavjud mablag‘ doirasida ariza yuboring. To‘lov qo‘lda ko‘rib chiqiladi."}</p><form method="post" enctype="${isDeposit ? "multipart/form-data" : "application/x-www-form-urlencoded"}" action="/${kind}"><label>Summa (so‘m)</label><input name="amount" type="number" min="1000" max="10000000" required>${isDeposit ? '<label>Chek (JPG, PNG, WEBP yoki PDF, 4 MB gacha)</label><input name="proof" type="file" accept=".jpg,.jpeg,.png,.webp,.pdf" required>' : '<label>To‘lov uchun izoh (ixtiyoriy)</label><input name="note" maxlength="200" placeholder="Masalan, karta egasi ismi">'}<button>Ariza yuborish</button></form><p class="muted">Sayt hech qachon PIN, CVV yoki SMS tasdiqlash kodini so‘ramaydi.</p></section>`, req);
}
app.get("/", (req, res) => {
  const body = `<section class="hero"><span class="badge">VAZIFALAR PLATFORMASI</span><h1>Vazifalarni bajaring.<br><span class="green">Mukofotlarni kuzating.</span></h1><p>UZBAT — vazifalar, arizalar va hisob-kitoblarni kuzatish uchun platforma boshlang‘ich versiyasi.</p><div class="actions"><a class="button" href="${req.session.userId ? "/dashboard" : "/register"}">${req.session.userId ? "Kabinetga kirish" : "Ro‘yxatdan o‘tish"}</a><a class="button secondary" href="/login">Kirish</a></div></section><section class="box"><h2>Qanday ishlaydi?</h2><div class="grid"><div class="metric"><b>1. Hisob yarating</b><p>Login va parol bilan ro‘yxatdan o‘ting.</p></div><div class="metric"><b>2. Vazifa bajaring</b><p>Hamkor vazifalarini bajaring va natijani yuboring.</p></div><div class="metric"><b>3. Tekshiruv</b><p>Admin tasdiqlagan haqiqiy to‘lovlar va mukofotlar hisoblanadi.</p></div></div></section><section class="notice"><b>Sarmoya haqida:</b> ushbu boshlang‘ich versiya sarmoya qabul qilmaydi va kunlik foydani kafolatlamaydi. Sarmoya mahsulotini yoqishdan oldin qonuniy talablar, daromad manbasi va to‘lov qobiliyati mustaqil tekshirilishi kerak.</section>`;
  res.send(page("Bosh sahifa", body, req));
});
app.get("/register", (req,res) => res.send(page("Ro‘yxatdan o‘tish", `${flash(req)}<section class="box narrow"><h1>Hisob yaratish</h1><form method="post"><label>Login (3–24 belgi)</label><input name="username" minlength="3" maxlength="24" pattern="[A-Za-z0-9_]+" required><label>Parol (kamida 10 belgi)</label><input type="password" name="password" minlength="10" required><button>Ro‘yxatdan o‘tish</button></form></section>`,req)));
app.post("/register", async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  if (!/^[A-Za-z0-9_]{3,24}$/.test(username) || password.length < 10) {
    req.session.flash = "Login yoki parol talablarga mos emas."; return res.redirect("/register");
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(username,password_hash) VALUES(?,?)").run(username,hash);
    req.session.userId = Number(info.lastInsertRowid); req.session.username = username; req.session.isAdmin = false;
    res.redirect("/dashboard");
  } catch { req.session.flash = "Bu login band bo‘lishi mumkin."; res.redirect("/register"); }
});
app.get("/login", (req,res) => res.send(page("Kirish", `${flash(req)}<section class="box narrow"><h1>Kirish</h1><form method="post"><label>Login</label><input name="username" required><label>Parol</label><input type="password" name="password" required><button>Kirish</button></form><p>Hisob yo‘qmi? <a href="/register">Ro‘yxatdan o‘tish</a></p></section>`,req)));
app.post("/login", async (req,res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const adminName = process.env.ADMIN_USERNAME || "admin";
  const adminPass = process.env.ADMIN_PASSWORD || "";
  if (adminPass && username === adminName && await bcrypt.compare(password, await bcrypt.hash(adminPass, 12))) {
    req.session.regenerate(err => {
      if (err) return res.status(500).send("Sessiya xatosi");
      req.session.userId = -1; req.session.username = adminName; req.session.isAdmin = true; res.redirect("/admin");
    }); return;
  }
  const user = db.prepare("SELECT * FROM users WHERE username=?").get(username);
  if (!user || !(await bcrypt.compare(password,user.password_hash))) {
    req.session.flash = "Login yoki parol noto‘g‘ri."; return res.redirect("/login");
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).send("Sessiya xatosi");
    req.session.userId = user.id; req.session.username = user.username; req.session.isAdmin = false; res.redirect("/dashboard");
  });
});
app.post("/logout", (req,res) => req.session.destroy(() => res.redirect("/")));

app.get("/dashboard", requireUser, (req,res) => {
  if (req.session.isAdmin) return res.redirect("/admin");
  const bal = balance(req.session.userId);
  const tasks = db.prepare("SELECT * FROM tasks WHERE active=1 ORDER BY id").all();
  const requests = db.prepare("SELECT * FROM requests WHERE user_id=? ORDER BY id DESC LIMIT 10").all(req.session.userId);
  const taskHtml = tasks.map(t => `<div class="task"><div><b>${esc(t.title)}</b><p>${esc(t.description)}</p><small>Mukofot: ${money(t.reward)}</small></div><form method="post" action="/task/${t.id}"><button>Natijani yuborish</button></form></div>`).join("");
  const reqHtml = requests.length ? `<div class="tablewrap"><table><tr><th>Turi</th><th>Summa</th><th>Holati</th><th>Sana</th></tr>${requests.map(r=>`<tr><td>${r.kind==="deposit"?"To‘ldirish":r.kind==="withdraw"?"Yechish":"Vazifa"}</td><td>${money(r.amount)}</td><td>${r.status==="pending"?"Kutilmoqda":r.status==="approved"?"Tasdiqlandi":"Rad etildi"}</td><td>${esc(r.created_at)}</td></tr>`).join("")}</table></div>` : "<p>Hozircha arizalar yo‘q.</p>";
  res.send(page("Kabinet", `${flash(req)}<section class="box"><h1>Salom, ${esc(req.session.username)}!</h1><p>Joriy balans</p><div class="big green">${money(bal)}</div><div class="actions"><a class="button" href="/deposit">Hisobni to‘ldirish</a><a class="button secondary" href="/withdraw">Pul yechish</a></div></section><section class="box"><h2>Vazifalar</h2>${taskHtml || "<p>Hozircha faol vazifa yo‘q.</p>"}</section><section class="box"><h2>Oxirgi arizalar</h2>${reqHtml}</section>`,req));
});
app.get("/deposit", requireUser, (req,res) => res.send(requestForm("deposit","Hisobni to‘ldirish",req)));
app.post("/deposit", requireUser, upload.single("proof"), (req,res) => {
  const amount = Number(req.body.amount);
  if (!Number.isInteger(amount) || amount < 1000 || amount > 10000000 || !req.file) {
    if (req.file) fs.unlink(req.file.path,()=>{});
    req.session.flash = "Summa noto‘g‘ri yoki chek yuklanmadi."; return res.redirect("/deposit");
  }
  db.prepare("INSERT INTO requests(user_id,kind,amount,proof_file) VALUES(?,?,?,?)").run(req.session.userId,"deposit",amount,req.file.filename);
  req.session.flash = "Ariza yuborildi. Admin chekni tekshirgach javob ko‘rinadi."; res.redirect("/dashboard");
});
app.get("/withdraw", requireUser, (req,res) => res.send(requestForm("withdraw","Pul yechish",req)));
app.post("/withdraw", requireUser, (req,res) => {
  const amount = Number(req.body.amount), bal = balance(req.session.userId);
  if (!Number.isInteger(amount) || amount < 1000 || amount > bal) {
    req.session.flash = "Summa noto‘g‘ri yoki balans yetarli emas."; return res.redirect("/withdraw");
  }
  db.prepare("INSERT INTO requests(user_id,kind,amount,note) VALUES(?,?,?,?)").run(req.session.userId,"withdraw",amount,String(req.body.note||"").slice(0,200));
  req.session.flash = "Pul yechish arizasi yuborildi."; res.redirect("/dashboard");
});
app.post("/task/:id", requireUser, (req,res) => {
  const task = db.prepare("SELECT * FROM tasks WHERE id=? AND active=1").get(Number(req.params.id));
  if (!task) { req.session.flash = "Vazifa topilmadi."; return res.redirect("/dashboard"); }
  const exists = db.prepare("SELECT id FROM requests WHERE user_id=? AND kind='task' AND note=? AND status!='rejected'").get(req.session.userId,`task:${task.id}`);
  if (exists) { req.session.flash = "Bu vazifa bo‘yicha ariza oldin yuborilgan."; return res.redirect("/dashboard"); }
  db.prepare("INSERT INTO requests(user_id,kind,amount,note) VALUES(?,?,?,?)").run(req.session.userId,"task",task.reward,`task:${task.id}`);
  req.session.flash = "Vazifa natijasi tekshiruvga yuborildi."; res.redirect("/dashboard");
});
app.get("/admin", requireAdmin, (req,res) => {
  const requests = db.prepare(`SELECT r.*,u.username FROM requests r JOIN users u ON u.id=r.user_id ORDER BY CASE r.status WHEN 'pending' THEN 0 ELSE 1 END, r.id DESC LIMIT 200`).all();
  const users = db.prepare("SELECT COUNT(*) n FROM users").get().n;
  const rows = requests.map(r => `<tr><td>${r.id}</td><td>${esc(r.username)}</td><td>${r.kind==="deposit"?"To‘ldirish":r.kind==="withdraw"?"Yechish":"Vazifa"}</td><td>${money(r.amount)}</td><td>${esc(r.status)}</td><td>${r.proof_file ? `<a href="/receipts/${encodeURIComponent(r.proof_file)}" target="_blank" rel="noopener">Chekni ko‘rish</a>` : esc(r.note)}</td><td>${r.status==="pending"?`<form method="post" action="/admin/request/${r.id}/approve" class="inline"><button>Tasdiqlash</button></form> <form method="post" action="/admin/request/${r.id}/reject" class="inline"><button class="danger">Rad etish</button></form>`:"—"}</td></tr>`).join("");
  const tasks = db.prepare("SELECT * FROM tasks ORDER BY id").all();
  const taskRows = tasks.map(t=>`<tr><td>${esc(t.title)}</td><td>${money(t.reward)}</td><td>${t.active?"Faol":"O‘chiq"}</td><td><form method="post" action="/admin/task/${t.id}/toggle"><button class="secondary">${t.active?"O‘chirish":"Yoqish"}</button></form></td></tr>`).join("");
  res.send(page("Admin", `${flash(req)}<section class="box"><h1>Admin paneli</h1><p>Foydalanuvchilar: <b>${users}</b> • Ko‘rsatilayotgan arizalar: <b>${requests.length}</b></p><p>Chekni tekshiring va faqat real to‘lov tushgani bank ilovasida tasdiqlangandan keyin arizani tasdiqlang.</p></section><section class="box"><h2>To‘lov, yechish va vazifa arizalari</h2><div class="tablewrap"><table><tr><th>ID</th><th>Foydalanuvchi</th><th>Turi</th><th>Summa</th><th>Holati</th><th>Chek/izoh</th><th>Amal</th></tr>${rows}</table></div></section><section class="box"><h2>Vazifalar</h2><div class="tablewrap"><table><tr><th>Nomi</th><th>Mukofot</th><th>Holati</th><th>Amal</th></tr>${taskRows}</table></div></section><section class="notice">Tasdiqlash balansga faqat real tushgan to‘lovni yoki tasdiqlangan vazifa mukofotini yozadi. Pul yechish arizasi tasdiqlanganda balansdan mablag‘ rezervlanadi; tashqi bank o‘tkazmasini admin alohida amalga oshiradi.</section>`,req));
});
app.post("/admin/request/:id/approve", requireAdmin, (req,res) => {
  const id = Number(req.params.id);
  const tx = db.transaction(() => {
    const r = db.prepare("SELECT * FROM requests WHERE id=? AND status='pending'").get(id);
    if (!r) return "Ariza topilmadi yoki allaqachon ko‘rib chiqilgan.";
    if (r.kind === "withdraw") {
      const bal = balance(r.user_id);
      if (bal < r.amount) return "Balans yetarli emas. Ariza rad etilmadi; foydalanuvchi bilan bog‘laning.";
      db.prepare("INSERT INTO ledger(user_id,amount,description) VALUES(?,?,?)").run(r.user_id,-r.amount,`Pul yechish arizasi #${r.id} — admin tasdiqladi`);
    } else {
      db.prepare("INSERT INTO ledger(user_id,amount,description) VALUES(?,?,?)").run(r.user_id,r.amount,`${r.kind==="deposit"?"To‘lov":"Vazifa mukofoti"} arizasi #${r.id} — admin tasdiqladi`);
    }
    db.prepare("UPDATE requests SET status='approved' WHERE id=?").run(id);
    return "Ariza tasdiqlandi. Pul yechish bo‘lsa, bank o‘tkazmasini alohida bajaring.";
  });
  req.session.flash = tx(); res.redirect("/admin");
});
app.post("/admin/request/:id/reject", requireAdmin, (req,res) => {
  const result = db.prepare("UPDATE requests SET status='rejected' WHERE id=? AND status='pending'").run(Number(req.params.id));
  req.session.flash = result.changes ? "Ariza rad etildi." : "Ariza topilmadi yoki oldin ko‘rilgan."; res.redirect("/admin");
});
app.post("/admin/task/:id/toggle", requireAdmin, (req,res) => {
  db.prepare("UPDATE tasks SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?").run(Number(req.params.id));
  res.redirect("/admin");
});
app.use((err,req,res,next) => {
  console.error(err.message);
  if (err instanceof multer.MulterError || err.message.includes("chek")) {
    req.session.flash = err.message; return res.redirect("/deposit");
  }
  res.status(500).send("Server xatosi. Keyinroq urinib ko‘ring.");
});
app.listen(PORT, () => console.log(`UZBAT running on port ${PORT}`));
